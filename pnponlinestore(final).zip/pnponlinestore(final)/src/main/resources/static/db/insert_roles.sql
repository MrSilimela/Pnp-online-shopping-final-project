INSERT INTO 'user' (1, 'CLIENT');
